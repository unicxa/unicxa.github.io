package com.sickray.games.BoE;

import java.net.MalformedURLException;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			@SuppressWarnings("unused")
			Splash sp = new Splash();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

 
	}

}
