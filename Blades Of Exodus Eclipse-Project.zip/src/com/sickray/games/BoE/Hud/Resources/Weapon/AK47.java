package com.sickray.games.BoE.Hud.Resources.Weapon;

public interface AK47 {

}
