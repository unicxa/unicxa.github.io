package com.sickray.games.BoE.Hud.Resources.Weapon;

public enum WeaponType {
	//Name Says it All

}
