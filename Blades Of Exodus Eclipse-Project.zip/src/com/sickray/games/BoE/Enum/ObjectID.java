package com.sickray.games.BoE.Enum;

public enum ObjectID {
	//List Of All Object(s) and ID's
	Grass(),
	Fire(),
	Sky(),
	EntityPlayer(),
	HUDGui();
	
	
	
	
	
}
