package com.sickray.games.BoE.Handlers;

public class BOEventHandler {

	public BOEventHandler() {
		// TODO Auto-generated constructor stub
	}

}
