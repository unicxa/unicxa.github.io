package com.sickray.games.BoE.Handlers;

public class BlockUpdateHandler {

	public BlockUpdateHandler() {
		// TODO Auto-generated constructor stub
	}

}
