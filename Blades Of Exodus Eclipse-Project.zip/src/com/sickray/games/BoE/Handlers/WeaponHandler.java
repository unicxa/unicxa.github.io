package com.sickray.games.BoE.Handlers;

public class WeaponHandler {

	public WeaponHandler() {
		// TODO Auto-generated constructor stub
	}

}
