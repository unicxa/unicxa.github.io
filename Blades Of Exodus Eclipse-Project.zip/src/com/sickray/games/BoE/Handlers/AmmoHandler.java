package com.sickray.games.BoE.Handlers;



public class AmmoHandler {
	//Ammo Event Handler

	public AmmoHandler () {
		


	}

}
